#ifndef SYMTAB_H
#define SYMTAB_H

#include <stdbool.h>

void declare_function(const char* name, const char* return_type, int param_count);
void enter_scope();
void exit_scope();
bool validate_main_function();
int is_function_declared(const char* name);

// ���� 4 � ������:
void begin_scope();
void end_scope();
bool is_var_declared_in_current_scope(const char* name);
void declare_var(const char* name);
void record_function_call(const char* name);

bool all_function_calls_are_valid();
#endif // SYMTAB_H
