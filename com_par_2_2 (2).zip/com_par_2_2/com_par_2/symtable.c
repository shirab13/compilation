#include "symtable.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define MAX_VARS 100
#define MAX_FUNCTIONS 100
#define MAX_SCOPES 100
#define MAX_CALLS 1000
extern int current_scope;
extern int scope_counter;
typedef struct {
    char name[64];
} Variable;

typedef struct {
    char name[64];
    char return_type[16];
    int param_count;
} Function;
char* called_functions[MAX_CALLS];
int call_count = 0;
Variable scopes[MAX_SCOPES][MAX_VARS];
int scope_sizes[MAX_SCOPES] = { 0 };
int current_scope = -1;

static Function function_table[MAX_FUNCTIONS];
static int function_count = 0;
void record_function_call(const char* name) {
    if (call_count >= MAX_CALLS) return;
    called_functions[call_count++] = strdup(name);
}
void declare_param(const char* name) {
    declare_var(name); // �� ����� ���� ����� ������ ����
}

bool all_function_calls_are_valid() {
    for (int i = 0; i < call_count; i++) {
        if (!is_function_declared(called_functions[i])) {
            fprintf(stderr, "Semantic error: Function '%s' called but not declared\n", called_functions[i]);
            return false;
        }
    }
    return true;
}
void declare_function(const char* name, const char* return_type, int param_count) {
    if (function_count >= MAX_FUNCTIONS) {
        fprintf(stderr, "Function table overflow\n");
        return;
    }
    strncpy(function_table[function_count].name, name, 63);
    strncpy(function_table[function_count].return_type, return_type, 15);
    function_table[function_count].param_count = param_count;
    function_count++;
}

int is_function_declared(const char* name) {
    for (int i = 0; i < function_count; i++) {
        if (strcmp(function_table[i].name, name) == 0)
            return 1;
    }
    return 0;
}

bool validate_main_function() {
    int main_count = 0;
    for (int i = 0; i < function_count; i++) {
        if (strcmp(function_table[i].name, "_main_") == 0) {
            main_count++;
            if (function_table[i].param_count != 0) {
                fprintf(stderr, "Semantic error: _main_ must not take parameters\n");
                return false;
            }
            if (strcmp(function_table[i].return_type, "void") != 0) {
                fprintf(stderr, "Semantic error: _main_ must return void\n");
                return false;
            }
        }
    }
    if (main_count == 0) {
        fprintf(stderr, "Semantic error: _main_ function is missing\n");
        return false;
    }
    if (main_count > 1) {
        fprintf(stderr, "Semantic error: _main_ function declared more than once\n");
        return false;
    }
    return true;
}

// ====== ������ �-scopes ======

void begin_scope() {
    current_scope++;
    if (current_scope >= MAX_SCOPES) {
        fprintf(stderr, "Too many nested scopes\n");
        exit(1);
    }
    scope_sizes[current_scope] = 0;
}


void end_scope() {
    if (current_scope >= 0)
        current_scope--;
}
void clear_scope_variables(int scope) {
    if (scope >= 0 && scope < MAX_SCOPES) {
        scope_sizes[scope] = 0;
    }
}

bool is_var_declared_in_current_scope(const char* name) {
    for (int i = 0; i < scope_sizes[current_scope]; i++) {
        if (strcmp(scopes[current_scope][i].name, name) == 0)
            return true;
    }
    return false;
}

void declare_var(const char* name) {
    if (current_scope < 0) {
        fprintf(stderr, "ERROR: declare_var called with current_scope = %d for '%s'\n", current_scope, name);
        exit(1);
    }

    printf("[DEBUG] Declaring variable '%s' in scope %d\n", name, current_scope);

    if (scope_sizes[current_scope] >= MAX_VARS) {
        fprintf(stderr, "Too many variables in current scope\n");
        exit(1);
    }
    strncpy(scopes[current_scope][scope_sizes[current_scope]].name, name, 63);
    scope_sizes[current_scope]++;
}

bool is_var_declared(const char* name) {
    for (int s = current_scope; s >= 0; s--) {
        for (int i = 0; i < scope_sizes[s]; i++) {
            if (strcmp(scopes[s][i].name, name) == 0)
                return true;
        }
    }
    return false;
}
int get_param_count(const char* fname) {
    for (int i = 0; i < function_count; i++) {

        if (strcmp(function_table[i].name, fname) == 0) {
            return function_table[i].param_count;
        }
    }
    return -1; // �� �� ����
}
