#ifndef SYMTAB_H
#define SYMTAB_H

#include <stdbool.h>

extern int current_scope;

void declare_function(const char* name, const char* return_type, int param_count);
bool validate_main_function();
int is_function_declared(const char* name);

// ���� 4 � ������:
void begin_scope();
void end_scope();
bool is_var_declared_in_current_scope(const char* name);
void declare_var(const char* name);
void record_function_call(const char* name);
bool is_var_declared(const char* name);
void clear_scope_variables(int scope);
void declare_param(const char* name); 
int get_param_count(const char* fname);
bool all_function_calls_are_valid();

#endif // SYMTAB_H
